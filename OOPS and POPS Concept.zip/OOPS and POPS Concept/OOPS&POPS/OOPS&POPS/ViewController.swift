//
//  ViewController.swift
//  OOPS&POPS
//
//  Created by Infodart on 22/01/19.
//  Copyright © 2019 Infodart. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
       applicationOfEquitableProtocol()
       understandingReferenceSemantic()
       understandingValueSemantic()
       understandingLine()

        let view = LineDrawingView()
        view.backgroundColor = .white
        self.view = view

        protocolPolymorphism()

        let viewObj = UIView()
        let frame = self.view.frame
        viewObj.backgroundColor = UIColor.green
        viewObj.frame = CGRect(x:frame.size.width/2 - (frame.size.width-200)/2 , y: frame.size.height-50, width: frame.size.width-200, height: 40)
        self.view.addSubview(viewObj)

        let gesture = UITapGestureRecognizer(target: self, action:  #selector (addViewButtonTapped (_:)))
        viewObj.addGestureRecognizer(gesture)
        
        
         understandinQueuUsingProtocol()
         understandinStackUsingProtocol()
        
        
        
        
        
    }
    
    @IBAction func addViewButtonTapped(_ sender: Any) {
        let customFrame0 = CGRect(x: 110, y: 100, width: 100, height: 100)
        let customView0 = SimpleUIViewBoarder(frame: customFrame0)
        customView0.addBorder()
        self.view.addSubview(customView0)
        
        let customFrame2 = CGRect(x: 110, y: 320, width: 100, height: 100)
        let customView2 = UIViewWithBoarder(boarderColor: .red, borderThickness: 10.0, frame: customFrame2)
        customView2.addBorder()
        self.view.addSubview(customView2)
        
    }
    
    func understandingReferenceSemantic() {
        let bat = ClsBat()
        bat.fly()
        
        let bird = ClsBird()
        bird.fly()
        
        let batCopy = bat
        batCopy.fly()
        
        batCopy.flightTermonology = ""
        batCopy.fly()
        
        bat.fly()
        
        
        /// discussion - You cannot assign one class type of other class type
        /*
        var batObj = ClsBat()
        var birdObj = ClsBird()
        batObj = birdObj
        print(batObj)
        birdObj = batObj
        print(birdObj)
       */
       
        
        
    }
    
    func understandingValueSemantic(){
        let bat = StructBat()
        bat.fly()
        
        let bird = StructBird()
        bird.fly()
        
        var batCopy = bat
        batCopy.fly()
        
        batCopy.flightTermonology = ""
        batCopy.fly()
        
        bat.fly()
        
    }
    
    
    func applicationOfEquitableProtocol() {
        let personObj1: Person = Person(name: "Roshan", weight: 60, sex: "M")
        let personObj2: Person = Person(name: "Roshan", weight: 60, sex: "M")
        
        let isEqual:Bool =  personObj1 == personObj2
        print(isEqual)
        
    }
    
    func understandingLine() {
        let x1 = CGPoint(x: 0, y: 0)
        let y1 = CGPoint(x: 2, y: 2)
        
        
        let line1 = Line(beginPoint: x1, endPoint: y1)
        let len1 =  line1.length()
        
        let x2 = CGPoint(x: 3, y: 2)
        let y2 = CGPoint(x: 5, y: 4)
        
        
        
        let line2 = Line(beginPoint: x2, endPoint: y2)
        let len2 = line2.length()
        
        
        if len1 == len2 {
            print("line1 == line2")
            
        }else{
            print("line1 != line2")
        }
        if(len1 > len2){
            print("line1 > line2")
            
        }else{
            print("line1 < line2")
            
        }
        if(len1 >= len2){
            print("line1 >= line2")
            
        }else{
            print("line1 <= line2")
            
        }
        
        
    }
    
    func protocolPolymorphism() {
        let top = TopStruct()
        let middle = MiddelStruct()
        let bottom = BottomStruct()
        
        var topProtocol: Top
        topProtocol = bottom
        print(topProtocol)
        
        topProtocol = middle
        print(topProtocol)
        
        topProtocol = top
        print(topProtocol)
        
        
        let protocolStructs:[Top] = [top,middle,bottom]
        
        for protocolStruct in protocolStructs {
            print(protocolStruct)
        }
    }
    
    
    
    
    func understandinQueuUsingProtocol() -> Void {
        /// Createing Queue of type Any (Generic)
        var queue = Queue<Any>()
        
        //adding element in queue of type String
        queue.add("Roshan")
        
        //adding element in queue of type Int
        queue.add(1)
        
        //Print list
        queue.showList()
        
        //adding element in queue of type float
        queue.add(3.0000)
        
        //getting element count in queue of type any
        let count = queue.count()
        print(count)
        
        //removing  element in queue of type any
        var elementRemoved = queue.remove()
        elementRemoved = queue.remove()
        print(elementRemoved)
        elementRemoved = queue.remove()
        print(elementRemoved)
        
        elementRemoved = queue.remove()
         print(elementRemoved)
        
    }
    
    func understandinStackUsingProtocol() -> Void {
        var stack = Stack<Any>()
        
        //adding element in queue of type String
        stack.add("Roshan")
        
        //adding element in queue of type Int
        stack.add(1)
        
        //Print list
        stack.showList()
        
        //adding element in queue of type float
        stack.add(3.0000)
        
        //getting element count in queue of type any
        let count = stack.count()
        print(count)
        
    }
    
}

