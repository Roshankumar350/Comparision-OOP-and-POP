//
//  Line.swift
//  OOPS&POPS
//
//  Created by Infodart on 23/01/19.
//  Copyright © 2019 Infodart. All rights reserved.
//

import Foundation
import UIKit

class Line : IsEqual, Comparable {
    
    
    var beginPoint:CGPoint
    var endPoint:CGPoint
    
    init() {
        beginPoint = CGPoint(x: 0, y: 0)
        endPoint   = CGPoint(x: 0, y: 0)
    }
    
    init(beginPoint: CGPoint, endPoint:CGPoint) {
        self.beginPoint = CGPoint(x: beginPoint.x, y: beginPoint.y)
        self.endPoint   = CGPoint(x: endPoint.x, y: endPoint.y)
    }
    
    func length() -> CGFloat {
        let length = sqrt(pow(endPoint.x - beginPoint.x, 2) + pow(endPoint.y, beginPoint.y) )
        return length
    }
    
    
    
    static func == (lhs: Line, rhs: Line) -> Bool {
        return lhs.length() == rhs.length()
    }
    
    static func != (lhs: Line, rhs: Line) -> Bool {
        return lhs.length() != rhs.length()
    }
    
    static func > (lhs: Line, rhs: Line) -> Bool {
        return lhs.length() > rhs.length()
    }
    
    static func < (lhs: Line, rhs: Line) -> Bool {
        return lhs.length() < rhs.length()
    }
    
    static func >= (lhs: Line, rhs: Line) -> Bool {
        return lhs.length() >= rhs.length()
    }
    
    static func <= (lhs: Line, rhs: Line) -> Bool {
        return lhs.length() <= rhs.length()
    }
    
    
    
}
