//
//  UIViewWithBoarder.swift
//  OOPS&POPS
//
//  Created by Infodart on 23/01/19.
//  Copyright © 2019 Infodart. All rights reserved.
//

import UIKit

class UIViewWithBoarder: UIView, ViewWithBoder {
    
    var borderColor: UIColor
    var borderThickness: CGFloat
    
    required init(boarderColor: UIColor, borderThickness: CGFloat, frame: CGRect) {
        self.borderColor = boarderColor
        self.borderThickness = borderThickness
        super.init(frame: frame)
    }
    
  
    
    // This initializer is required by UIView.
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    

    

}
