//
//  SimpleUIViewBoarder.swift
//  OOPS&POPS
//
//  Created by Infodart on 23/01/19.
//  Copyright © 2019 Infodart. All rights reserved.
//

import UIKit

class SimpleUIViewBoarder: UIView, simpleViewWidthBorder{
   
    /// comment this code to have default implementation
    /// default will be :-
//    layer.borderColor = UIColor.green.cgColor
//    layer.borderWidth = 10.0
    func addBorder() {
        layer.borderWidth = 20
        layer.borderColor = UIColor.purple.cgColor
    }

}
