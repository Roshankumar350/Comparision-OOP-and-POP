//
//  ProtocolDefination.swift
//  OOPS&POPS
//
//  Created by Infodart on 23/01/19.
//  Copyright © 2019 Infodart. All rights reserved.
//

import Foundation
import UIKit

protocol IsEqual {
    static func == (lhs : Self, rhs : Self) -> Bool
    static func != (lhs : Self, rhs : Self) -> Bool
}


protocol Comparable {
    static func >  (lhs : Self, rhs : Self) -> Bool
    static func <  (lhs : Self, rhs : Self) -> Bool
    static func >= (lhs : Self, rhs : Self) -> Bool
    static func <= (lhs : Self, rhs : Self) -> Bool
}



protocol simpleViewWidthBorder {
    
}

extension simpleViewWidthBorder where Self : UIView {
    func addBorder() -> Void {
        layer.borderColor = UIColor.green.cgColor
        layer.borderWidth = 10.0
    }
    
}

protocol ViewWithBoder where Self : UIView {
    var borderColor:UIColor { get }
    var borderThickness:CGFloat { get }
    init(boarderColor: UIColor, borderThickness : CGFloat, frame : CGRect )
}

extension ViewWithBoder {
    func addBorder() -> Void {
        layer.borderColor = borderColor.cgColor
        layer.borderWidth = borderThickness
        
    }
}
