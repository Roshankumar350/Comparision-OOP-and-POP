//
//  Protocol Polymorphism.swift
//  OOPS&POPS
//
//  Created by Infodart on 23/01/19.
//  Copyright © 2019 Infodart. All rights reserved.
//

import Foundation

/*!@ First protocol blueprint */
protocol Top {
    
    var protocolName : String { get }
}

/*!@ Second protocol blueprint */
protocol Middle : Top  {
    
}

/*!@ Third protocol blueprint */
protocol Bottom : Middle {
    
}


struct TopStruct : Top {
    var protocolName: String = "TopStruct"
    
    
}

struct MiddelStruct : Middle {
    var protocolName: String = "MiddelStruct"
    
    
}

struct BottomStruct : Bottom {
    var protocolName: String = "BottomStruct"

}
