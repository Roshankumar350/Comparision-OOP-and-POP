//
//  DependencyInjectionUsingProtocol.swift
//  OOPS&POPS
//
//  Created by Infodart on 30/01/19.
//  Copyright © 2019 Infodart. All rights reserved.
//

import Foundation
import UIKit

class DataManager {
    
}

protocol  DataManagerInjection {
    var dataManager: DataManager {get}
    
}

fileprivate let sharedAppDataManager:DataManager = DataManager()

extension DataManagerInjection {
    
    var dataManager : DataManager{
        return sharedAppDataManager
    }
    
}

