//
//  Fly.swift
//  OOPS&POPS
//
//  Created by Infodart on 22/01/19.
//  Copyright © 2019 Infodart. All rights reserved.
//

import Foundation

protocol ObjectThatFlies {
    var flightTermonology : String { get }
    func fly()
    
}
extension ObjectThatFlies{
    func fly(){
        let myType = String(describing: type(of: self))
        let flightTerminologyForType = myType + " " + flightTermonology  + "\n"
        print(flightTerminologyForType)
        
    }
}

class ClsBird: ObjectThatFlies {
    var flightTermonology: String = "fly with feathers and flap wings differently than bats"
   
    
    
}

class ClsBat: ObjectThatFlies {
    var flightTermonology: String = "flies WITHOUT feathers, and flaps wings differently than birds"
} 

