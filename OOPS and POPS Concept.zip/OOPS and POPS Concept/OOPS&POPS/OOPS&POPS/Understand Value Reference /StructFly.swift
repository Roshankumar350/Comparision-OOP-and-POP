//
//  StructFly.swift
//  OOPS&POPS
//
//  Created by Infodart on 22/01/19.
//  Copyright © 2019 Infodart. All rights reserved.
//

import Foundation

struct StructBird :ObjectThatFlies {
    var flightTermonology: String = "flies WITH feathers, and flaps wings differently than bats"
    
}

struct StructBat: ObjectThatFlies {
    var flightTermonology: String = "flies WITHOUT feathers, and flaps wings differently than birds"
}
