//
//  Person.swift
//  OOPS&POPS
//
//  Created by Infodart on 22/01/19.
//  Copyright © 2019 Infodart. All rights reserved.
//

import Foundation

class Person: Equatable {
    
    var name : String
    var weight : Int
    var sex : String
    
    init(name:String, weight: Int, sex:String) {
        self.name = name
        self.weight = weight
        self.sex = sex
    }
    
    
    static func == (lhs: Person, rhs: Person) -> Bool {
        if lhs.name == rhs.name && lhs.weight == rhs.weight && lhs.sex == rhs.sex {
            return true
        }else{
            return false
        }
    }
    
    
}

