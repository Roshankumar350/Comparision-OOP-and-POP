//
//  Queue.swift
//  OOPS&POPS
//
//  Created by Infodart on 24/01/19.
//  Copyright © 2019 Infodart. All rights reserved.
//

import Foundation


struct Queue <AnyType> :FIFO {
    var elements: [AnyType] = []
    
}
