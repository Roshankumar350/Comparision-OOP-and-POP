//
//  Stack.swift
//  OOPS&POPS
//
//  Created by Infodart on 24/01/19.
//  Copyright © 2019 Infodart. All rights reserved.
//

import Foundation

struct Stack<AnyType> : LIFO {
    var elements: [AnyType] = []
    
}
