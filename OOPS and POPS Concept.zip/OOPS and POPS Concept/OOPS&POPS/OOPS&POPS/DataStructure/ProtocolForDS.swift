//
//  ProtocolForDS.swift
//  OOPS&POPS
//
//  Created by Infodart on 24/01/19.
//  Copyright © 2019 Infodart. All rights reserved.
//

import Foundation

/// Conform "ListSubscript" protocol to access via index
protocol ListSubscript {
    associatedtype AnyType
    var elements: [ AnyType ] { get }
    
    
}

extension ListSubscript {
    subscript(i : Int) -> Any {
        return elements[i]
    }
}



/// Conform "ListPrintForward" protocol to print forward
protocol ListPrintForward {
    associatedtype AnyType
    var elements : [AnyType] { get }
}

extension ListPrintForward {
    /// Use "showList" method to print List in forward seek
    func showList() -> Void {
        if elements.count > 0 {
            var line = ""
            var index = 1
            
            for element in elements {
                line = line + "\(element) ||"
                index = index + 1
            }
            print("\(line) NULL \n")
            
        }else{
            print("EMPTY \n")
        }
    }
}


/// Conform "ListPrintBackward" protocol to print forward

protocol ListPrintBackward {
    associatedtype AnyType
    var elements:[AnyType] {get}
}

extension ListPrintBackward {
    /// Use "showList" method to print List in forward seek
    func showList() -> Void {
        if elements.count > 0 {
            var line = ""
            var index = 1
            
            for element in elements.reversed() {
                line = line + "|| \(element)"
                index = index + 1
            }
            print("\(line)")
            
        }else{
            print("EMPTY \n")
        }
    }
}

/// Conform "ListCount" protocol to use to get count
protocol ListCount {
    associatedtype Anytype
    var elements:[Anytype] { get }
}

extension ListCount {
    func count() -> Int {
        return elements.count
    }
}


/// Conform "List" protocol to use List related function
protocol List {
    associatedtype AnyType
    var elements:[AnyType] {get set}
    /// required  protocol need to be implemented who so ever type conform to it
    mutating func remove()-> AnyType
    mutating func add(_ element : AnyType)
    
}

extension List {
    mutating func add(_ element: AnyType) -> Void {
        elements.append(element)
    }
}

/// Conform "FIFO" protocol to use Queue Data structure

/*
 * Quenue Implementation
 */
protocol FIFO : List, ListCount, ListPrintForward{
    
}

extension FIFO {
    
    mutating func remove() -> AnyType {
        if elements.count > 0{
            return elements.removeFirst()
        }else{
            return "*****EMPTY******" as! Self.AnyType
        }
        
    }
}

/*
 * Stack Implementation
 */
protocol LIFO : List, ListCount, ListPrintBackward{
    
    
}

extension LIFO {
    
    mutating func remove() ->AnyType {
        if elements.count > 0{
            return elements.removeLast()
        }else {
            return "***** EMPTY STACK ******" as! Self.AnyType
        }
    }
}
