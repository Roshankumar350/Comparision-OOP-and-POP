//
//  ProtocolForLinkedList.swift
//  OOPS&POPS
//
//  Created by Infodart on 29/01/19.
//  Copyright © 2019 Infodart. All rights reserved.
//

import Foundation



protocol NodeProtocol : class {
    associatedtype AnyType
    var tag:String? {get}
    var payload : AnyType? {get set}
    var next:Self? {get set}
    var previous:Self? {get set}
    
    init(with payload: AnyType, named tag:String)
    
}


final class Node<AnyType> :NodeProtocol {
    
    var tag: String?
    var payload: AnyType?
    var next: Node<AnyType>?
    var previous: Node<AnyType>?
    
    init(with payload: AnyType, named tag: String) {
        self.payload = payload
        self.tag = tag
        print("Allocating node tagged: [\(tag)]")
    }
    
    deinit {
        print("Deallocating node tagged: [\(tag!)]")
    }
    
    
}
