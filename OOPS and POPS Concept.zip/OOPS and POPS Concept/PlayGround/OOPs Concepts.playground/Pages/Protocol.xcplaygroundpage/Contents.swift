import UIKit

protocol Copyable {
    var copyOfSelf: Self { get }
}

final class Car {
    
    let name: String
    init(name: String) { self.name = name }
}

extension Car: Copyable {
    var copyOfSelf: Car { return Car(name: self.name) }
}

let objCar = Car(name: "Maruti 800")
print(objCar.name)
print(objCar.copyOfSelf.name)


