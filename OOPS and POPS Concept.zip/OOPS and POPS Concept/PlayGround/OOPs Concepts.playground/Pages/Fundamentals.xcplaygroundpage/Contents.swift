//: [Previous](@previous)

import Foundation
/*!@ Defination:- OOPs is a programming paradigm that is associated with concepts of Class
 * and Objects which use Inheritance, Polymorphism, Abstraction, Encapsulation to implement
 * bussiness logics in simplified way so that we can resusability.
 *
 */

/*
 * We will understand concept using an Instrument class
 * Instrument -> 1. Piano
 *               2. Guitar -> a. Acoustics Gitar b. Electric Guitar c. Bass Guitar
 */

/*!@ Class Musics
 * Its objective is to encapsulate an array of notes and flatten it into a string
 */
class Music{
    let notes :[String]
    
    init(notes : [String]) {
        self.notes = notes
    }
    
    func prepared() -> String {
        return notes.joined(separator: " ")
    }
    
}




/*!@ Instrument is Base Class
 * Class :- Class is the blue print which in which we define methods and properties
 */
class Instrument{
    /*!@ Its a property that will identify the Instrument brand
     * Stored property :- It use to store the constant or variable.
     */
    let brand: String
    
    /*!@ Initialising brand whenever this class is initialise
     * Its a constructor that initialise class with brand stored property
     */
    init(brand: String) {
        self.brand = brand
    }
    
    /*!@ Methods :- Function defined inside a class are called methods because they have access to properties
     * Note :- Classes with methods like this are said to be Abstract Class
     * Abstract Class :- Abstract classes are classes that are intended to be subclasses
     * and methods and properties should be override.
     * Absttract class should not be initialised
     */
    func tune() -> String {
        fatalError("Implement this method for \(brand)")
        
    }
    
    func play(_ music : Music) -> String {
        return music.prepared()
    }
    
    func perform(_ music : Music) {
        print(tune())
        print(play(music))
    }
    
}


/* ------------------------------------------------------------------------------------------------------------- */


class Piano : Instrument{
    let hasPedals : Bool
    /*!@ All pionios will have same no. of whites and black keys */
    static let whiteKey = 52
    static let blackKey = 36
    
    /*Constructors */
    init(brand: String, hasPedals: Bool = false) {
        self.hasPedals = hasPedals
        /* Super to call parents class initialiser */
        super.init(brand: brand)
    }
    
    /* Method overriding */
    override func tune() -> String {
        return "Piano standard tuning for \(brand)."
    }
    
    /* Method overriding */
    override func play(_ music: Music) -> String {
//        let preparedNotes = super.play(music)
//        return "Piano playing \(preparedNotes)"
        return play(music, usingPedals: hasPedals)
    }
    
    /* Methods Overloading */
    func play(_ music: Music, usingPedals: Bool) -> String {
        let preparedNotes = super.play(music)
        if hasPedals && usingPedals {
            return "Play piano notes \(preparedNotes) with pedals."
        }
        else {
            return "Play piano notes \(preparedNotes) without pedals."
        }
    }
    
}


let piano = Piano(brand: "Yahama", hasPedals: true)
piano.tune()

let music = Music(notes: ["A","B","C","D"])
/* Method Overriding */
piano.play(music, usingPedals: false)
piano.play(music)

/*!@ Note:- we call the static properties directly using class name */
Piano.whiteKey
Piano.blackKey


