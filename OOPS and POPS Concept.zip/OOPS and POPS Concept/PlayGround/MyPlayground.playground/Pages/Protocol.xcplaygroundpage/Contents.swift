import Foundation
/*
 * Defination of Protocol
 */
print("===============Protocol Defination START =================================\n")

print("A protocol defines a blueprint of methods, properties, and other requirements that suit a particular task or piece of functionality.")
print("It can be adopted by Class, Structure, Enumeration")

print()
print("===============Protocol Defination End =================================\n")

print("===============Protocol Overloading START =================================\n")

protocol ParentProtocol {
    //     func testPrint()
}

extension ParentProtocol {
    func testPrint() ->String {
        return "ParentProtocol testPrint() call"
    }
    
    func testPrint(name:String)->String {
       return "\(name) testPrint() call"
    }
    
}
class ParentClass : ParentProtocol {
    
}

let parentObj = ParentClass()
print(parentObj.testPrint())
print(parentObj.testPrint(name: "ParentProtocol"))

print()
print("===============Protocol Overloading END =================================\n")


print("===============Protocol Overriding START =================================\n")

protocol ParentProtocol1 {
    //     func testPrint()
}

extension ParentProtocol1 {
    func testPrint()->String {
        return "ParentProtocol extension call"
    }
}

protocol ChildProtocol1 :ParentProtocol1 {
    
}

extension ChildProtocol1 {
    
    func testPrint()->String {
       return "ChildProtocol extension call"
    }
    
}

class MyParentClass : ChildProtocol1 {
    
}
//To call ParentProtocol1 testPrint() comment out ChildProtocol1 testPrint()
print(MyParentClass().testPrint())




print("===============Protocol Overriding ENDS =================================\n")


print("===============Protocol Default Implementation START =================================\n")


protocol ParentProtocol2 {
    //     func testPrint()
}

extension ParentProtocol2 {
    func defaultImplementation(){
        print("ParentProtocol2 extension call")
    }
}

class MyParentClass1 : ParentProtocol2 {
    
    func defaultImplementation(){
        (self as ParentProtocol2).defaultImplementation()
        print("MyParentClass1 class can have its own setup")
    }
    
}

let myPC1 = MyParentClass1()
myPC1.defaultImplementation()


print()
print("===============Protocol Default Implementation END =================================\n")
