//: [Previous](@previous)

import Foundation

protocol ListSubScript{
    associatedtype AnyType
    var elements:[ AnyType] { get }
}

extension ListSubScript {
    subscript(_ i : Int) -> AnyType{
        return elements[i]
    }
    
}

protocol List{
    associatedtype AnyType
    var elements:[ AnyType] { get set }
    mutating func addElement(_ element: AnyType) -> Void
    mutating func removeElement() -> Void
    
}

extension List {
    mutating func addElement(_ element: AnyType) -> Void {
        self.elements.append(element)
        
    }
}

protocol PrintForward {
    associatedtype AnyType
    var elements: [AnyType] { get }
    
}

extension PrintForward {
    
    func display() -> Void {
        
        for element in elements {
             print(element, separator: "",terminator: "||")
        }
    }
    
}

protocol FIFO : List, PrintForward {
    associatedtype AnyType
    var elements:[AnyType] {get set}
    
    
}

extension FIFO {
    mutating func removeElement() -> Void{
        elements.removeFirst()
        
    }
}


struct Queue<AnyType> : FIFO{
    var elements: [AnyType] = []
    
}


class MyClassA{
    
    func CallMe() {
        var queue = Queue<Any>()
        queue.addElement("Hello")
        queue.addElement(10)
        queue.display()
        queue.removeElement()
        print()
        queue.display()
        
    }
    
}

let obj = MyClassA()
obj.CallMe()


//: [Next](@next)
