
import Foundation

//When programming in Swift, think about polymorphism through protocols first, before resorting to inheritance.

/*
 * Lets look how polymorphism works
 */

class Parent {
    let name : String
    let age : Int
    let sex : String
    
    init(name : String ,age : Int, sex : String) {
        self.name = name
        self.age = age
        self.sex = sex
    }
    
    /* Polymorphism can be achived though method overloading and method overriding
     * Method overloading :- Takes place in same class having same signature but different param
     * Ex :- Here we have two method having same signature but different parameter.
     * Method overriding :-  Takes place in parent child  class having same signature
     */
    func helloParent() -> String {
        if self.sex == "M" {
            return "\(self.name) says Hello to you"
        }else if(self.sex == "F"){
            return "\(self.name) says Hi to you"
        }else{
            return "You are no my parent"
        }
        
    }
    
    func helloParent(sex : String) -> String {
        if sex == "M" {
            return "\(self.name) overloaded says Hello to you"
        }else if(sex == "F"){
            return "\(self.name) overloaded says Hi to you"
        }else{
            return "You are no my parent"
        }
        
    }
    
    func defaultImplementation() {
        print("You are providing default implementation")
    }
    
}
/*
 * Uncomment to understand method overloading
 */

//let parentObj = Parent(name: "PAPA",age: 54, sex: "M")
//parentObj.helloParent()
//parentObj.helloParent(sex:"M")

class Child : Parent {
    
    override func helloParent() -> String {
        if self.sex == "M" {
            return "\(self.name) says Hello to you from Child Class"
        }else if(self.sex == "F"){
            return "\(self.name) says Hi to you from Child Class "
        }else{
            return "You are no my parent"
        }

    }
    
}

/*
 * Method Overriding
 */
let childObj1 = Child(name : "Babu", age: 15, sex: "M")
childObj1.helloParent()
// Please note if helloParent() defination is not defined in Child Class it will print helloParent of Parent class
// comment helloParent() in child to see in action


/*
 * Method Overriding occur here using parentObj1
 * Note: Here we initialise Child Class by the type of parent class
 */
let parentObj1 : Parent = Child(name: "PAPA",age: 54, sex: "M")
parentObj1.helloParent()


/* ********---->THIS WILL NOT WORK <----********
 * Reason :- Child doesnot have capability to absorb parent type while Parents have the capability to absorb child type
 * Method Overriding occur here using childObj2
 * Note: Here we initialise Parents Class by the type of child class
 */

/*
let childObj2 : Child = Parent(name: "PAPA",age: 54, sex: "M") as! Child
childObj2.helloParent()
 */

/*
 * Providing default implementation through Class
 * Please Not we cannot have ABSTRACT CLASS  in swift and Objective C
 *
 */
class Child1 : Parent {
    init() {
        super.init(name: "Child1",age: 26,sex : "M")
    }
    
    override func defaultImplementation(){
        super.defaultImplementation()
        print("Yes I have provided default implementation and did something extra here")
    }
    
}

let child1Obj = Child1()
child1Obj.defaultImplementation()
